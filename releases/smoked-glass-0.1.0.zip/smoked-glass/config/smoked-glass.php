<?php

declare(strict_types=1);

// Defaults mirror Ehaic\SmokedGlass\Support\Settings::DEFAULTS. Saved through Admin > Plugins > Smoked Glass > Settings
// (written to the panel .env); values are sanitised again before they reach any CSS.
return [
    'accent' => env('SMOKED_GLASS_ACCENT', 'sky'),
    'accent_custom' => env('SMOKED_GLASS_ACCENT_CUSTOM', '#56c2ff'),
    'blur' => env('SMOKED_GLASS_BLUR', 40),
    'opacity' => env('SMOKED_GLASS_OPACITY', 0.50),
    'blobs' => env('SMOKED_GLASS_BLOBS', true),
    'grain' => env('SMOKED_GLASS_GRAIN', true),
    'animate' => env('SMOKED_GLASS_ANIMATE', true),
];
