<?php

return [
    'settings' => [
        'saved' => 'Smoked Glass settings saved.',
        'save_failed' => 'Could not save the Smoked Glass settings',
        'save_failed_env' => 'Check that the panel can write to its .env file.',
        'look' => 'Look',
        'look_hint' => 'Changes preview live behind this window; Save to keep them.',
        'accent' => 'Accent colour',
        'custom' => 'Custom',
        'accent_custom' => 'Custom accent (hex)',
        'accent_custom_hint' => 'Dark colours are lightened automatically so text stays readable (WCAG AA).',
        'blur' => 'Glass blur (px)',
        'blur_hint' => 'Default 40. Lower values are cheaper to render on slow GPUs; 0 turns the blur off.',
        'opacity' => 'Glass opacity',
        'opacity_hint' => 'Default 0.50. Higher = more solid surfaces.',
        'background' => 'Background',
        'blobs' => 'Soft background blobs',
        'grain' => 'Film grain',
        'animate' => 'Animate the background',
        'animate_hint' => 'Slow drift of the blobs. Always off when the browser asks for reduced motion.',
        'reset' => 'Reset to defaults',
        'reset_hint' => 'Switch on to put every option back to its default. Nothing is saved until you press Submit.',
        'reset_done' => 'Defaults restored in the form. Save to keep them.',
    ],
];
