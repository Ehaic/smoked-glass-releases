<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Support;

/**
 * Turns sanitised settings into the dynamic part of the theme: the --sg-* tokens on :root, Filament's
 * --primary-/--gray-/--danger-/--success-/--warning-* ramps, and the few switch rules (blobs/grain/animation).
 * The static look lives in resources/css/smoked-glass.css and only references these variables.
 */
final class CssBuilder
{
    /**
     * @param  array<string, mixed>  $settings  any array; it is sanitised here again so callers cannot inject
     */
    public static function variables(array $settings, bool $explicit = false): string
    {
        $s = Settings::sanitize($settings);
        $a = Settings::accentColors($s);
        $accentRgb = Color::rgbString($a['accent']);
        $surfRgb = Color::rgbString(Tokens::SURFACE);
        $txtRgb = Color::rgbString(Tokens::TEXT);

        $v = [
            '--sg-accent' => $a['accent'],
            '--sg-accent-2' => $a['light'],
            '--sg-rgb' => $accentRgb,
            '--sg-b1' => $a['b1'],
            '--sg-b2' => $a['b2'],
            '--sg-on-accent' => $a['on'],
            '--sg-bg' => Tokens::BG,
            '--sg-surface' => Tokens::SURFACE,
            '--sg-surface-rgb' => $surfRgb,
            '--sg-text' => Tokens::TEXT,
            '--sg-text-rgb' => $txtRgb,
            '--sg-muted' => Tokens::MUTED,
            '--sg-line' => "rgba({$txtRgb},.10)",
            '--sg-red' => Tokens::RED,
            '--sg-ok' => Tokens::OK,
            '--sg-warn' => Tokens::WARN,
            '--sg-radius' => Tokens::RADIUS . 'px',
            '--sg-radius-sm' => Tokens::RADIUS_SM . 'px',
            '--sg-blur' => $s['blur'] . 'px',
            '--sg-opacity' => self::num($s['opacity']),
            '--sg-backdrop' => 'blur(var(--sg-blur)) saturate(135%)',
            '--sg-glass' => 'linear-gradient(135deg,rgba(var(--sg-text-rgb),.03),transparent 50%),rgba(var(--sg-surface-rgb),var(--sg-opacity))',
            '--sg-glass-shadow' => 'inset 0 1px 0 rgba(var(--sg-text-rgb),.18),inset 0 0 0 1px rgba(var(--sg-text-rgb),.09),0 12px 40px rgba(0,0,0,.22)',
            '--sg-glass-solid' => Tokens::SURFACE,
        ];

        // Filament ramps: primary follows the accent, gray is the slate ramp, status colours are the design-system tags.
        $primary = self::ramp($a['accent']);
        foreach ($primary as $shade => $hex) {
            $v["--primary-{$shade}"] = $hex;
        }
        foreach (Tokens::GRAY as $shade => $hex) {
            $v["--gray-{$shade}"] = $hex;
            $v["--sg-gray-{$shade}"] = $hex;
        }
        foreach ([['danger', Tokens::RED], ['success', Tokens::OK], ['warning', Tokens::WARN], ['info', $a['accent']]] as [$name, $hex]) {
            foreach (self::ramp($hex) as $shade => $c) {
                $v["--{$name}-{$shade}"] = $c;
            }
        }

        $css = ':root{color-scheme:dark;';
        foreach ($v as $name => $value) {
            $css .= $name . ':' . $value . ';';
        }
        $css .= '}';
        // Switches. Only fixed strings are emitted here, never user input.
        // $explicit (the live preview in the settings modal) also emits the "on" rules so it can override a saved "off".
        if (!$s['blobs']) {
            $css .= '.sg-bg i{display:none}';
        } elseif ($explicit) {
            $css .= '.sg-bg i{display:block}';
        }
        if (!$s['grain']) {
            $css .= '.sg-bg:before{display:none}';
        } elseif ($explicit) {
            $css .= '.sg-bg:before{display:block}';
        }
        if (!$s['animate']) {
            $css .= '.sg-bg i{animation:none!important;will-change:auto}';
        } elseif ($explicit) {
            $css .= '.sg-bg i{animation-play-state:running}';
        }

        return $css;
    }

    /**
     * 11-step ramp around a base colour (the base sits at 500, lighter steps mix with white, darker with black).
     *
     * @return array<int,string>
     */
    public static function ramp(string $base): array
    {
        $out = [];
        foreach ([50 => .92, 100 => .84, 200 => .68, 300 => .48, 400 => .24] as $shade => $amt) {
            $out[$shade] = Color::mix($base, '#ffffff', $amt);
        }
        $out[500] = $base;
        foreach ([600 => .14, 700 => .30, 800 => .46, 900 => .62, 950 => .76] as $shade => $amt) {
            $out[$shade] = Color::mix($base, '#000000', $amt);
        }
        ksort($out);

        return $out;
    }

    /** Stable cache-busting token: plugin version + hash of the dynamic and static CSS. */
    public static function version(string $version, string $dynamic, string $static): string
    {
        return $version . '-' . substr(hash('sha256', $dynamic . "\0" . $static), 0, 8);
    }

    private static function num(float $n): string
    {
        $s = rtrim(rtrim(number_format($n, 2, '.', ''), '0'), '.');

        return $s === '' ? '0' : (str_starts_with($s, '0.') ? substr($s, 1) : $s);
    }
}
