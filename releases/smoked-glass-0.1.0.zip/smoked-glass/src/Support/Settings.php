<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Support;

/**
 * Smoked Glass settings: defaults, accent presets, sanitising (lenient, for rendering) and validation (strict, for saving).
 * Everything that ends up inside the injected <style> block goes through here, so only whitelisted values,
 * normalised hex colours and clamped numbers can ever reach the CSS.
 */
final class Settings
{
    public const DEFAULTS = [
        'accent' => 'sky',
        'accent_custom' => '#56c2ff',
        'blur' => 40,
        'opacity' => 0.50,
        'blobs' => true,
        'grain' => true,
        'animate' => true,
    ];

    public const BLUR_RANGE = [0, 60];
    public const OPACITY_RANGE = [0.20, 0.95];

    /**
     * Accent presets: accent (text/outline), light (headings on glass, link hover), b1/b2 (primary button gradient).
     * Sky is the design-system default (feedback-log 2026-11-12).
     */
    public const PRESETS = [
        'sky' => ['label' => 'Sky', 'accent' => '#56c2ff', 'light' => '#a6e0ff', 'b1' => '#7fd2ff', 'b2' => '#2aa6f0'],
        'azure' => ['label' => 'Azure', 'accent' => '#4d9bff', 'light' => '#a9ccff', 'b1' => '#7db6ff', 'b2' => '#2a74e8'],
        'cobalt' => ['label' => 'Cobalt', 'accent' => '#7d98ff', 'light' => '#c0ccff', 'b1' => '#93a9ff', 'b2' => '#3a5be0'],
        'steel' => ['label' => 'Steel', 'accent' => '#8fa8c4', 'light' => '#cdd9e6', 'b1' => '#aebfd3', 'b2' => '#6b88a8'],
        'ice' => ['label' => 'Ice', 'accent' => '#b8e6ff', 'light' => '#e2f5ff', 'b1' => '#d3f0ff', 'b2' => '#8cc9ee'],
    ];

    /**
     * Lenient: take anything (config values, stale env), return a complete, safe settings array. Invalid fields fall back
     * to their default individually, numbers are clamped.
     *
     * @param  array<string, mixed>  $in
     * @return array{accent:string,accent_custom:string,blur:int,opacity:float,blobs:bool,grain:bool,animate:bool}
     */
    public static function sanitize(array $in): array
    {
        $d = self::DEFAULTS;
        $accent = $in['accent'] ?? $d['accent'];
        $accent = is_string($accent) && (isset(self::PRESETS[$accent]) || $accent === 'custom') ? $accent : $d['accent'];

        return [
            'accent' => $accent,
            'accent_custom' => Color::normalizeHex($in['accent_custom'] ?? null) ?? $d['accent_custom'],
            'blur' => (int) self::clamp($in['blur'] ?? null, self::BLUR_RANGE, (float) $d['blur']),
            'opacity' => round(self::clamp($in['opacity'] ?? null, self::OPACITY_RANGE, (float) $d['opacity']), 2),
            'blobs' => self::bool($in['blobs'] ?? null, $d['blobs']),
            'grain' => self::bool($in['grain'] ?? null, $d['grain']),
            'animate' => self::bool($in['animate'] ?? null, $d['animate']),
        ];
    }

    /**
     * Strict: used when saving. Returns [clean settings, errors by field]. Errors mean "do not save".
     *
     * @param  array<string, mixed>  $in
     * @return array{0:array<string,mixed>,1:array<string,string>}
     */
    public static function validate(array $in): array
    {
        $errors = [];
        $accent = $in['accent'] ?? null;
        if (!is_string($accent) || !(isset(self::PRESETS[$accent]) || $accent === 'custom')) {
            $errors['accent'] = 'Choose one of the accent presets or custom.';
        }
        $custom = $in['accent_custom'] ?? null;
        if (($accent === 'custom' || ($custom !== null && $custom !== '')) && Color::normalizeHex($custom) === null) {
            $errors['accent_custom'] = 'Enter a hex colour such as #56c2ff.';
        }
        foreach (['blur' => self::BLUR_RANGE, 'opacity' => self::OPACITY_RANGE] as $key => [$min, $max]) {
            $v = $in[$key] ?? null;
            if (!is_int($v) && !is_float($v) && !(is_string($v) && is_numeric($v))) {
                $errors[$key] = 'Enter a number.';
            } elseif ((float) $v < $min || (float) $v > $max) {
                $errors[$key] = "Must be between {$min} and {$max}.";
            }
        }
        foreach (['blobs', 'grain', 'animate'] as $key) {
            if (!array_key_exists($key, $in) || !(is_bool($in[$key]) || in_array($in[$key], [0, 1, '0', '1', 'true', 'false'], true))) {
                $errors[$key] = 'Must be on or off.';
            }
        }

        return [self::sanitize($in), $errors];
    }

    /** @param array{0:int|float,1:int|float} $range */
    private static function clamp(mixed $v, array $range, float $default): float
    {
        if (!is_int($v) && !is_float($v) && !(is_string($v) && is_numeric($v))) {
            return $default;
        }
        $f = (float) $v;
        if (!is_finite($f)) {
            return $default;
        }

        return max((float) $range[0], min((float) $range[1], $f));
    }

    private static function bool(mixed $v, bool $default): bool
    {
        if (is_bool($v)) {
            return $v;
        }
        if (in_array($v, [1, '1', 'true', 'on', 'yes'], true)) {
            return true;
        }
        if (in_array($v, [0, '0', 'false', 'off', 'no'], true)) {
            return false;
        }

        return $default;
    }

    /**
     * Resolved accent colours for a settings array (custom accents get a derived light tone and button gradient,
     * and are lightened until they reach WCAG AA (4.5:1) as text on the base background).
     *
     * @param  array<string, mixed>  $s  sanitised settings
     * @return array{accent:string,light:string,b1:string,b2:string,on:string}
     */
    public static function accentColors(array $s): array
    {
        $bg = Tokens::BG;
        if (($s['accent'] ?? 'sky') !== 'custom' && isset(self::PRESETS[$s['accent'] ?? 'sky'])) {
            $p = self::PRESETS[$s['accent']];
            $accent = $p['accent'];
            $light = $p['light'];
            $b1 = $p['b1'];
            $b2 = $p['b2'];
        } else {
            $base = Color::normalizeHex($s['accent_custom'] ?? null) ?? self::PRESETS['sky']['accent'];
            $accent = Color::ensureContrast($base, $bg, 4.5);
            $light = Color::ensureContrast(Color::mix($accent, '#ffffff', 0.45), $bg, 7.0);
            $b1 = Color::mix($base, '#ffffff', 0.25);
            $b2 = Color::mix($base, '#000000', 0.18);
        }

        return ['accent' => $accent, 'light' => $light, 'b1' => $b1, 'b2' => $b2, 'on' => Color::contrast($b2, '#0b1220') >= 4.5 && Color::contrast($b1, '#0b1220') >= 4.5 ? '#0b1220' : '#ffffff'];
    }
}
