<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Support;

/** Fixed (non-configurable) palette of the design system. Documented in docs/TOKENS.md. */
final class Tokens
{
    public const BG = '#101216';
    public const SURFACE = '#20232c';
    public const TEXT = '#eeeef5';
    public const MUTED = '#aeb1c2';
    public const RED = '#fda4af';
    public const OK = '#6ee7b7';
    public const WARN = '#f6b98a';
    public const RADIUS = 18;
    public const RADIUS_SM = 12;
    /** Mid-slate grey ramp for Filament's --gray-* variables (50 light .. 950 base). */
    public const GRAY = [
        50 => '#eeeef5', 100 => '#dfe0ea', 200 => '#c9cbda', 300 => '#aeb1c2', 400 => '#9a9eb1',
        500 => '#8387a0', 600 => '#5d6174', 700 => '#3a3e4c', 800 => '#262932', 900 => '#181b21', 950 => '#101216',
    ];
}
