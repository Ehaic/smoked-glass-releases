<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass;

use App\Contracts\Plugins\HasPluginSettings;
use App\Traits\EnvironmentWriterTrait;
use Ehaic\SmokedGlass\Http\FontController;
use Ehaic\SmokedGlass\Support\CssBuilder;
use Ehaic\SmokedGlass\Support\Settings;
use Ehaic\SmokedGlass\Support\Tokens;
use Filament\Contracts\Plugin;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Panel;
use Filament\Schemas\Components\Html;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\HtmlString;
use Throwable;

/**
 * Smoked Glass v4 (Smoked Clear dark / Frost light, following Filament's own theme switch): static CSS
 * (resources/css/smoked-glass.css) + a dynamic block of --sg-* variables, injected inline into <head> through render hooks
 * (no Vite build). Fonts are served by a public panel route. Panels: app, admin, server.
 */
class SmokedGlassPlugin implements HasPluginSettings, Plugin
{
    use EnvironmentWriterTrait;

    public const VERSION = '0.2.0';

    public function getId(): string
    {
        return 'smoked-glass';
    }

    public function register(Panel $panel): void
    {
        // v0.2.0: no more forced dark mode. Filament's own System/Light/Dark switch works and toggles the `dark` class on
        // <html>; every token below flips with it (docs/DECISIONS.md, 2).
        $panel->darkMode(true, false);
        if (enum_exists(\Filament\Enums\ThemeMode::class)) {
            $panel->defaultThemeMode(\Filament\Enums\ThemeMode::System);
        }

        // Public (no login) font route: the login page needs the fonts too.
        $panel->routes(static function () use ($panel): void {
            Route::get('smoked-glass/fonts/{file}', FontController::class)->name('smoked-glass.font');
        });

        $panelId = $panel->getId();
        $panel->renderHook('panels::styles.after', static fn (): HtmlString => new HtmlString(self::themeResetHtml()));
        $panel->renderHook('panels::head.end', static fn (): HtmlString => new HtmlString(self::headHtml(self::currentSettings(), self::fontBase($panelId))));
        $panel->renderHook('panels::body.start', static fn (): HtmlString => new HtmlString(self::backgroundHtml()));
    }

    /** Relative URL prefix of the font route for a panel, or null when the route is not registered. */
    public static function fontBase(string $panelId): ?string
    {
        try {
            $name = "filament.{$panelId}.smoked-glass.font";
            if (!Route::has($name)) {
                return null;
            }

            return rtrim((string) preg_replace('~/[^/]*$~', '', route($name, ['file' => Tokens::FONTS[0]], false)), '/');
        } catch (Throwable) {
            return null;
        }
    }

    /**
     * One-time (per browser) reset of Filament's stored theme mode. 0.1.0 forced dark and wrote
     * localStorage `filament:theme:mode = dark` on every page load, which would pin the panel to dark after the upgrade
     * even though the switcher is back. Runs before Filament's own theme script (styles.after hook), once.
     */
    public static function themeResetHtml(): string
    {
        return '<script>try{if(!localStorage.getItem("smoked-glass:theme-reset")){if(localStorage.getItem("filament:theme:mode")==="dark")localStorage.removeItem("filament:theme:mode");localStorage.setItem("smoked-glass:theme-reset","1")}}catch(e){}</script>';
    }

    public function boot(Panel $panel): void {}

    /** @return array<string, mixed> */
    private static function currentSettings(): array
    {
        $configured = config('smoked-glass', []);

        return Settings::sanitize(is_array($configured) ? $configured : []);
    }

    /** @param array<string, mixed> $settings */
    public static function headHtml(array $settings, ?string $fontBase = null): string
    {
        $dynamic = CssBuilder::variables($settings, false, $fontBase, self::VERSION);
        $static = self::staticCss();
        $version = CssBuilder::version(self::VERSION, $dynamic, $static);

        // CSS text cannot contain "</style" (it comes from a trusted file and a whitelisted builder), belt and braces:
        $css = str_ireplace('</style', '<\\/style', $dynamic . $static);

        $preload = $fontBase !== null && preg_match('~^[A-Za-z0-9/_.:-]+$~D', $fontBase) === 1
            ? '<link rel="preload" href="' . e($fontBase . '/' . Tokens::FONTS[0] . '?v=' . self::VERSION) . '" as="font" type="font/woff2" crossorigin>'
            : '';

        return '<meta name="theme-color" media="(prefers-color-scheme: dark)" content="' . Tokens::BG_DARK . '">'
            . '<meta name="theme-color" media="(prefers-color-scheme: light)" content="' . Tokens::BG_LIGHT . '">'
            . $preload
            . '<style id="smoked-glass-css" data-version="' . e($version) . '">' . $css . '</style>';
    }

    public static function backgroundHtml(): string
    {
        // Decorative only: four blobs (animated with transform only), dot grid and grain are pseudo-elements/CSS.
        return '<div class="sg-bg" aria-hidden="true"><i></i><i></i><i></i><i></i></div>';
    }

    private static ?string $css = null;

    private static function staticCss(): string
    {
        if (self::$css === null) {
            $file = dirname(__DIR__) . '/resources/css/smoked-glass.css';
            $css = is_file($file) ? (string) file_get_contents($file) : '';
            // strip comments and blank lines; keep it a plain, debuggable stylesheet
            $css = (string) preg_replace('~/\*.*?\*/~s', '', $css);
            self::$css = trim((string) preg_replace('~\n\s*\n+~', "\n", $css));
        }

        return self::$css;
    }

    /** @return array<string, mixed> */
    public function getSettingsFormData(): array
    {
        return self::currentSettings();
    }

    /** @return array<int, mixed> */
    public function getSettingsForm(): array
    {
        $options = [];
        foreach (Settings::PRESETS as $key => $p) {
            $options[$key] = $p['label'];
        }
        $options['custom'] = trans('smoked-glass::strings.settings.custom');
        $tintOptions = [];
        foreach (Tokens::TINTS as $key => $t) {
            $tintOptions[$key] = trans('smoked-glass::strings.settings.tint_' . $key);
        }

        // Radio labels cannot carry HTML in Filament 5, so the swatches are a separate, purely decorative strip.
        $swatches = '<div class="sg-swatches" aria-hidden="true">';
        foreach (Settings::PRESETS as $p) {
            $swatches .= '<span class="sg-sw" style="--sw:' . e($p['accent']) . '"></span>';
        }
        $swatches .= '<span class="sg-sw sg-sw-custom"></span></div>';

        $preview = static function (Get $get): HtmlString {
            $state = [
                'accent' => $get('accent'),
                'accent_custom' => $get('accent_custom'),
                'tint' => $get('tint'),
                'blur' => $get('blur'),
                'opacity' => $get('opacity'),
                'blobs' => $get('blobs'),
                'grain' => $get('grain'),
                'animate' => $get('animate'),
            ];

            // Live preview: the same builder, sanitised, scoped to the lifetime of the modal (removed with it).
            return new HtmlString('<style id="smoked-glass-live">' . CssBuilder::variables($state, true) . '</style>');
        };

        return [
            Section::make(trans('smoked-glass::strings.settings.look'))
                ->description(trans('smoked-glass::strings.settings.look_hint'))
                ->schema([
                    Radio::make('accent')
                        ->label(trans('smoked-glass::strings.settings.accent'))
                        ->options($options)->inline()->inlineLabel(false)
                        ->live()->required(),
                    Html::make(new HtmlString($swatches))->columnSpanFull(),
                    TextInput::make('accent_custom')
                        ->label(trans('smoked-glass::strings.settings.accent_custom'))
                        ->helperText(trans('smoked-glass::strings.settings.accent_custom_hint'))
                        ->placeholder('#56c2ff')->maxLength(7)
                        ->regex('/^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/')
                        ->live(onBlur: true)
                        ->visible(fn (Get $get): bool => $get('accent') === 'custom'),
                    Radio::make('tint')
                        ->label(trans('smoked-glass::strings.settings.tint'))
                        ->helperText(trans('smoked-glass::strings.settings.tint_hint'))
                        ->options($tintOptions)->inline()->inlineLabel(false)
                        ->live()->required(),
                    TextInput::make('blur')
                        ->label(trans('smoked-glass::strings.settings.blur'))
                        ->helperText(trans('smoked-glass::strings.settings.blur_hint'))
                        ->numeric()->minValue(Settings::BLUR_RANGE[0])->maxValue(Settings::BLUR_RANGE[1])->step(1)
                        ->required()->live(onBlur: true),
                    TextInput::make('opacity')
                        ->label(trans('smoked-glass::strings.settings.opacity'))
                        ->helperText(trans('smoked-glass::strings.settings.opacity_hint'))
                        ->numeric()->minValue(Settings::OPACITY_RANGE[0])->maxValue(Settings::OPACITY_RANGE[1])->step(0.05)
                        ->required()->live(onBlur: true),
                ])->columns(2),
            Section::make(trans('smoked-glass::strings.settings.background'))
                ->schema([
                    Toggle::make('blobs')->label(trans('smoked-glass::strings.settings.blobs'))->inline(false)->live(),
                    Toggle::make('grain')->label(trans('smoked-glass::strings.settings.grain'))->inline(false)->live(),
                    Toggle::make('animate')->label(trans('smoked-glass::strings.settings.animate'))
                        ->helperText(trans('smoked-glass::strings.settings.animate_hint'))->inline(false)->live(),
                ])->columns(3),
            // A switch instead of an Actions component: it renders reliably inside Pelican's slide-over and stays live.
            Toggle::make('reset')
                ->label(trans('smoked-glass::strings.settings.reset'))
                ->helperText(trans('smoked-glass::strings.settings.reset_hint'))
                ->inline(false)->dehydrated(false)->default(false)->live()
                ->afterStateUpdated(function (bool $state, Set $set): void {
                    if (!$state) {
                        return;
                    }
                    foreach (Settings::DEFAULTS as $key => $value) {
                        $set($key, $value);
                    }
                    $set('reset', false);
                    Notification::make()->title(trans('smoked-glass::strings.settings.reset_done'))->success()->send();
                }),
            Html::make($preview),
        ];
    }

    /** @param array<string, mixed> $data */
    public function saveSettings(array $data): void
    {
        [$clean, $errors] = Settings::validate($data);
        if ($errors !== []) {
            Notification::make()->title(trans('smoked-glass::strings.settings.save_failed'))->body(implode(' ', $errors))->danger()->send();

            return;
        }

        try {
            $this->writeToEnvironment([
                'SMOKED_GLASS_ACCENT' => $clean['accent'],
                'SMOKED_GLASS_ACCENT_CUSTOM' => $clean['accent_custom'],
                'SMOKED_GLASS_TINT' => $clean['tint'],
                'SMOKED_GLASS_BLUR' => $clean['blur'],
                'SMOKED_GLASS_OPACITY' => $clean['opacity'],
                'SMOKED_GLASS_BLOBS' => $clean['blobs'] ? 'true' : 'false',
                'SMOKED_GLASS_GRAIN' => $clean['grain'] ? 'true' : 'false',
                'SMOKED_GLASS_ANIMATE' => $clean['animate'] ? 'true' : 'false',
            ]);
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(trans('smoked-glass::strings.settings.save_failed'))
                ->body(trans('smoked-glass::strings.settings.save_failed_env'))->danger()->send();

            return;
        }

        config()->set('smoked-glass', $clean);
        Notification::make()->title(trans('smoked-glass::strings.settings.saved'))->success()->send();
    }
}
