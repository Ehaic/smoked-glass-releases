<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Support;

/**
 * Turns sanitised settings into the dynamic part of the theme: the --sg-* tokens (dark values on :root and html.dark,
 * Frost values on html:not(.dark), so Filament's own `dark` class on <html> switches them), Filament's
 * --primary-/--gray-/--danger-/--success-/--warning-* ramps, the @font-face rules and the few switch rules
 * (blobs/grain/animation). The static look lives in resources/css/smoked-glass.css and only references these variables.
 */
final class CssBuilder
{
    /**
     * @param  array<string, mixed>  $settings  any array; it is sanitised here again so callers cannot inject
     * @param  bool  $explicit  live preview: also emit the "on" switch rules so it can override a saved "off"
     * @param  string|null  $fontBase  URL prefix of the font route (no trailing slash), null = no @font-face (system fonts)
     */
    public static function variables(array $settings, bool $explicit = false, ?string $fontBase = null, string $fontVersion = ''): string
    {
        $s = Settings::sanitize($settings);
        $a = Settings::accentColors($s);

        $common = [
            '--sg-radius' => Tokens::RADIUS . 'px',
            '--sg-radius-sm' => Tokens::RADIUS_SM . 'px',
            '--sg-radius-lg' => Tokens::RADIUS . 'px',
            '--sg-radius-xl' => Tokens::RADIUS_XL . 'px',
            '--sg-font' => Tokens::FONT_STACK,
            '--sg-font-mono' => Tokens::FONT_MONO_STACK,
            '--sg-icon-stroke' => '1.75',
            '--sg-icon-sm' => '16px',
            '--sg-icon-md' => '18px',
            '--sg-icon-lg' => '22px',
            '--sg-dur-fast' => '150ms',
            '--sg-dur-base' => '220ms',
            '--sg-ease' => 'cubic-bezier(.2,.8,.2,1)',
            '--sg-backdrop' => 'blur(var(--sg-blur)) saturate(var(--sg-saturate))',
            // Filament's own font variables (it sets them in a <style> before this block)
            '--font-family' => Tokens::FONT_STACK,
            '--mono-font-family' => Tokens::FONT_MONO_STACK,
        ];

        $css = self::fontFaces($fontBase, $fontVersion);
        $css .= ':root{' . self::decl($common) . '}';
        $css .= ':root,html.dark{color-scheme:dark;' . self::decl(self::theme('dark', $s, $a)) . '}';
        $css .= 'html:not(.dark){color-scheme:light;' . self::decl(self::theme('light', $s, $a)) . '}';

        // Switches. Only fixed strings are emitted here, never user input.
        if (!$s['blobs']) {
            $css .= '.sg-bg i{display:none}';
        } elseif ($explicit) {
            $css .= '.sg-bg i{display:block}';
        }
        if (!$s['grain']) {
            $css .= '.sg-bg:before{display:none}';
        } elseif ($explicit) {
            $css .= '.sg-bg:before{display:block}';
        }
        if (!$s['animate']) {
            $css .= '.sg-bg i{animation:none!important;will-change:auto}';
        } elseif ($explicit) {
            $css .= '.sg-bg i{animation-play-state:running}';
        }

        return $css;
    }

    /**
     * All tokens of one theme.
     *
     * @param  'dark'|'light'  $mode
     * @param  array<string, mixed>  $s  sanitised settings
     * @param  array<string, string>  $a  Settings::accentColors()
     * @return array<string, string>
     */
    public static function theme(string $mode, array $s, array $a): array
    {
        $light = $mode === 'light';
        $T = $light ? Tokens::LIGHT : Tokens::DARK;
        $glow = $light ? $a['b2'] : $a['accent'];
        $ink = $light ? $a['ink'] : $a['accent'];
        $accent2 = $light ? $a['ink'] : $a['light'];
        $glowRgb = Color::rgbString($glow);

        $opacity = $light ? min(0.95, round($s['opacity'] + Tokens::OPACITY_LIGHT_OFFSET, 2)) : $s['opacity'];
        $blur = $light ? min(60, $s['blur'] + Tokens::BLUR_LIGHT_OFFSET) : $s['blur'];
        $strong = min(0.97, max($T['strong'], round($opacity + $T['strong_over'], 2)));
        $menu = min(0.98, max($T['menu'], $strong));

        $blobs = [Color::rgbaFromRgb(Color::rgbString($a['accent']), $T['blob_accent_alpha']), $T['blobs'][1], $T['blobs'][2], $T['blobs'][3]];
        $tint = Tokens::TINTS[$s['tint']][$mode] ?? null;
        if (is_array($tint)) {
            $blobs[0] = $tint[0];
            $blobs[1] = $tint[1];
            $blobs[2] = $tint[2];
        }

        $v = [
            // accent
            '--sg-accent' => $ink,
            '--sg-ink' => $ink,
            '--sg-accent-2' => $accent2,
            '--sg-glow' => $glow,
            '--sg-rgb' => $glowRgb,
            '--sg-b1' => $a['b1'],
            '--sg-b2' => $a['b2'],
            '--sg-on-accent' => $a['on'],
            '--sg-accent-soft' => 'rgba(var(--sg-rgb),' . ($light ? '.12' : '.10') . ')',
            '--sg-accent-edge' => 'rgba(var(--sg-rgb),' . ($light ? '.45' : '.45') . ')',
            '--sg-steel' => $T['steel'],
            // base + text
            '--sg-bg' => $T['bg'],
            '--sg-surface' => $T['surface'],
            '--sg-surface-raised' => $T['raised'],
            '--sg-surface-rgb' => $T['glass_rgb'],
            '--sg-text' => $T['text'],
            '--sg-text-rgb' => $T['text_rgb'],
            '--sg-text-2' => $T['text2'],
            '--sg-muted' => $T['muted'],
            '--sg-faint' => $T['faint'],
            '--sg-line' => $T['line'],
            '--sg-line-strong' => $T['line_strong'],
            '--sg-scrim' => $T['scrim'],
            '--sg-sheen' => $T['sheen'],
            '--sg-well' => $T['well'],
            '--sg-field' => $T['field'],
            '--sg-track' => $T['track'],
            '--sg-knob' => $T['knob'],
            '--sg-dot' => $T['dot'],
            // status (+ tints that follow the theme)
            '--sg-red' => $T['red'],
            '--sg-ok' => $T['ok'],
            '--sg-warn' => $T['warn'],
            '--sg-red-tint' => 'color-mix(in srgb,var(--sg-red) 12%,transparent)',
            '--sg-ok-tint' => 'color-mix(in srgb,var(--sg-ok) 12%,transparent)',
            '--sg-warn-tint' => 'color-mix(in srgb,var(--sg-warn) 12%,transparent)',
            '--sg-red-edge' => 'color-mix(in srgb,var(--sg-red) 50%,transparent)',
            '--sg-ok-edge' => 'color-mix(in srgb,var(--sg-ok) 45%,transparent)',
            '--sg-warn-edge' => 'color-mix(in srgb,var(--sg-warn) 45%,transparent)',
            '--sg-red-b1' => $T['red_b1'],
            '--sg-red-b2' => $T['red_b2'],
            '--sg-on-red' => $T['on_red'],
            '--sg-on-status' => $T['on_status'],
            '--sg-sheen-btn' => $T['sheen_btn'],
            // glass levels: ground < glass < strong glass (overlays)
            '--sg-blur' => $blur . 'px',
            '--sg-saturate' => $T['saturate'],
            '--sg-opacity' => self::num($opacity),
            '--sg-opacity-strong' => self::num($strong),
            '--sg-opacity-menu' => self::num($menu),
            '--sg-glass' => 'linear-gradient(135deg,var(--sg-sheen),transparent 50%),rgba(var(--sg-surface-rgb),var(--sg-opacity))',
            '--sg-glass-strong' => 'linear-gradient(135deg,var(--sg-sheen),transparent 50%),rgba(var(--sg-surface-rgb),var(--sg-opacity-strong))',
            '--sg-glass-menu' => 'linear-gradient(135deg,var(--sg-sheen),transparent 50%),rgba(var(--sg-surface-rgb),var(--sg-opacity-menu))',
            '--sg-glass-sticky' => 'rgba(var(--sg-surface-rgb),' . self::num($T['sticky']) . ')',
            '--sg-glass-solid' => $T['surface'],
            '--sg-glass-solid-strong' => $T['raised'],
            '--sg-glass-shadow' => $T['shadow'],
            '--sg-shadow-float' => $T['shadow_float'],
            '--sg-shadow-primary' => '0 4px 18px rgba(var(--sg-rgb),.35)',
            '--sg-shadow-stripe' => '0 0 10px rgba(var(--sg-rgb),' . ($light ? '.55' : '.60') . ')',
            // background layer
            '--sg-blob-1' => $blobs[0], '--sg-blob-2' => $blobs[1], '--sg-blob-3' => $blobs[2], '--sg-blob-4' => $blobs[3],
            '--sg-grain' => $T['grain'],
        ];
        foreach ($T['chart'] as $i => $hex) {
            $v['--sg-chart-' . ($i + 1)] = $hex;
        }
        foreach ($T['seq'] as $i => $hex) {
            $v['--sg-seq-' . ($i + 1)] = $hex;
        }

        // Filament ramps. Light: the 600 step carries the text-strength colour (Filament uses 600 for text/focus in light mode).
        $gray = $light ? Tokens::GRAY_LIGHT : Tokens::GRAY_DARK;
        foreach ($gray as $shade => $hex) {
            $v["--gray-{$shade}"] = $hex;
            $v["--sg-gray-{$shade}"] = $hex;
        }
        $v += self::rampVars('primary', $light ? $glow : $a['accent'], $light ? $a['ink'] : null);
        $v += self::rampVars('info', $light ? $glow : $a['accent'], $light ? $a['ink'] : null);
        $v += self::rampVars('danger', $T['red'], $light ? $T['red'] : null);
        $v += self::rampVars('success', $T['ok'], $light ? $T['ok'] : null);
        $v += self::rampVars('warning', $T['warn'], $light ? $T['warn'] : null);

        return $v;
    }

    /**
     * @return array<string, string>
     */
    private static function rampVars(string $name, string $base, ?string $at600): array
    {
        $out = [];
        $ramp = self::ramp($base);
        if ($at600 !== null) {
            // darker steps are derived from the text-strength colour, lighter ones stay from the base
            foreach ([600 => 0, 700 => .16, 800 => .32, 900 => .50, 950 => .68] as $shade => $amt) {
                $ramp[$shade] = Color::mix($at600, '#000000', $amt);
            }
        }
        foreach ($ramp as $shade => $hex) {
            $out["--{$name}-{$shade}"] = $hex;
        }

        return $out;
    }

    /** @param array<string, string> $vars */
    private static function decl(array $vars): string
    {
        $css = '';
        foreach ($vars as $name => $value) {
            $css .= $name . ':' . $value . ';';
        }

        return $css;
    }

    /** @font-face for the self-hosted Geist fonts; nothing when there is no usable URL (system fonts then). */
    public static function fontFaces(?string $base, string $version = ''): string
    {
        if ($base === null || preg_match('~^[A-Za-z0-9/_.:-]+$~D', $base) !== 1) {
            return '';
        }
        $q = preg_match('~^[A-Za-z0-9.-]+$~D', $version) === 1 && $version !== '' ? '?v=' . $version : '';
        $css = '';
        foreach (['Geist' => Tokens::FONTS[0], 'Geist Mono' => Tokens::FONTS[1]] as $family => $file) {
            $css .= "@font-face{font-family:'{$family}';src:url('{$base}/{$file}{$q}') format('woff2');font-weight:100 900;font-style:normal;font-display:swap}";
        }

        return $css;
    }

    /**
     * 11-step ramp around a base colour (the base sits at 500, lighter steps mix with white, darker with black).
     *
     * @return array<int,string>
     */
    public static function ramp(string $base): array
    {
        $out = [];
        foreach ([50 => .92, 100 => .84, 200 => .68, 300 => .48, 400 => .24] as $shade => $amt) {
            $out[$shade] = Color::mix($base, '#ffffff', $amt);
        }
        $out[500] = $base;
        foreach ([600 => .14, 700 => .30, 800 => .46, 900 => .62, 950 => .76] as $shade => $amt) {
            $out[$shade] = Color::mix($base, '#000000', $amt);
        }
        ksort($out);

        return $out;
    }

    /** Stable cache-busting token: plugin version + hash of the dynamic and static CSS. */
    public static function version(string $version, string $dynamic, string $static): string
    {
        return $version . '-' . substr(hash('sha256', $dynamic . "\0" . $static), 0, 8);
    }

    private static function num(float $n): string
    {
        $s = rtrim(rtrim(number_format($n, 2, '.', ''), '0'), '.');

        return $s === '' ? '0' : (str_starts_with($s, '0.') ? substr($s, 1) : $s);
    }
}
