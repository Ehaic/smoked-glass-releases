<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Support;

/**
 * Fixed (non-configurable) palette of the design system v4 (andrew-design-system, tag v4). One table per theme:
 * DARK = Smoked Clear, LIGHT = Frost. This file and Settings::PRESETS are the only places with raw colours;
 * the static stylesheet only references the --sg-* variables built from them (a test enforces it).
 * Documented in docs/TOKENS.md.
 */
final class Tokens
{
    public const RADIUS = 18;
    public const RADIUS_SM = 12;
    public const RADIUS_XL = 22;

    /** Fonts shipped in resources/fonts (OFL, from the design system). Whitelist for the font route. */
    public const FONTS = ['Geist-Variable.woff2', 'GeistMono-Variable.woff2'];
    public const FONT_STACK = 'Geist, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    public const FONT_MONO_STACK = '"Geist Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';

    /** Dark: Smoked Clear. */
    public const DARK = [
        'bg' => '#101216', 'surface' => '#20232c', 'raised' => '#272b36',
        'glass_rgb' => '32,35,44', 'text' => '#eeeef5', 'text_rgb' => '238,238,245',
        'text2' => '#d6d7e3', 'muted' => '#aeb1c2', 'faint' => '#8a8ea3',
        'line' => 'rgba(238,238,245,.10)', 'line_strong' => 'rgba(238,238,245,.20)',
        'red' => '#fda4af', 'ok' => '#6ee7b7', 'warn' => '#fcd34d', 'steel' => '#708cab',
        'red_b1' => '#ffc2cb', 'red_b2' => '#f4788c', 'on_red' => '#2a0b12',
        'on_status' => '#0b1220', 'sheen_btn' => 'rgba(255,255,255,.28)', 'sticky' => 1.0,
        'scrim' => 'rgba(8,9,12,.62)', 'sheen' => 'rgba(238,238,245,.03)',
        'well' => 'rgba(8,10,14,.30)', 'field' => 'rgba(16,18,22,.55)',
        'track' => 'rgba(238,238,245,.14)', 'knob' => '#eeeef5', 'dot' => 'rgba(238,238,245,.16)',
        'shadow' => 'inset 0 1px 0 rgba(238,238,245,.12),inset 0 0 0 1px rgba(238,238,245,.042),0 12px 40px rgba(0,0,0,.18)',
        'shadow_float' => 'inset 0 1px 0 rgba(238,238,245,.14),inset 0 0 0 1px rgba(238,238,245,.06),0 24px 70px rgba(0,0,0,.45)',
        'blobs' => ['rgba(86,194,255,.42)', 'rgba(52,96,214,.46)', 'rgba(112,140,171,.42)', 'rgba(166,224,255,.20)'],
        'blob_accent_alpha' => '.42',
        'chart' => ['#2a96dc', '#d95926', '#199e70', '#c98500', '#d55181', '#9085e9'],
        'seq' => ['#1d5583', '#226ca6', '#2a88c8', '#56b0ea', '#a6e0ff'],
        'saturate' => '135%', 'grain' => '.07',
        'opacity' => 0.38, 'blur' => 28, 'strong' => 0.78, 'strong_over' => 0.40, 'menu' => 0.97,
    ];

    /** Light: Frost. Glass opacity/blur follow the settings plus an offset (OPACITY_LIGHT_OFFSET, BLUR_LIGHT_OFFSET). */
    public const LIGHT = [
        'bg' => '#e6ebf2', 'surface' => '#f6f8fb', 'raised' => '#ffffff',
        'glass_rgb' => '255,255,255', 'text' => '#141821', 'text_rgb' => '20,24,33',
        'text2' => '#2f3646', 'muted' => '#545c70', 'faint' => '#8a91a5',
        'line' => 'rgba(20,28,45,.10)', 'line_strong' => 'rgba(20,28,45,.20)',
        'red' => '#be123c', 'ok' => '#047857', 'warn' => '#92580a', 'steel' => '#5b7594',
        'red_b1' => '#d1365a', 'red_b2' => '#be123c', 'on_red' => '#ffffff',
        'on_status' => '#ffffff', 'sheen_btn' => 'rgba(255,255,255,.30)', 'sticky' => 1.0,
        'scrim' => 'rgba(20,26,38,.35)', 'sheen' => 'rgba(255,255,255,.35)',
        'well' => 'rgba(20,28,45,.045)', 'field' => 'rgba(255,255,255,.70)',
        'track' => 'rgba(20,28,45,.12)', 'knob' => '#ffffff', 'dot' => 'rgba(20,28,45,.13)',
        'shadow' => 'inset 0 1px 0 rgba(255,255,255,.85),inset 0 0 0 1px rgba(255,255,255,.45),0 1px 2px rgba(20,28,45,.06),0 12px 32px rgba(20,28,45,.10)',
        'shadow_float' => 'inset 0 1px 0 rgba(255,255,255,.90),0 0 0 1px rgba(20,28,45,.08),0 24px 60px rgba(20,28,45,.22)',
        'blobs' => ['rgba(86,194,255,.55)', 'rgba(110,140,240,.42)', 'rgba(140,165,195,.45)', 'rgba(255,255,255,.90)'],
        'blob_accent_alpha' => '.55',
        'chart' => ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#6250d6'],
        'seq' => ['#6db2e2', '#4396d4', '#2479bf', '#145f9f', '#0a447a'],
        'saturate' => '160%', 'grain' => '.04',
        'opacity' => 0.55, 'blur' => 32, 'strong' => 0.86, 'strong_over' => 0.31, 'menu' => 0.97,
    ];

    /** Light = dark + offset, so one "opacity" and one "blur" setting drive both themes (defaults .38/28 and .55/32). */
    public const OPACITY_LIGHT_OFFSET = 0.17;
    public const BLUR_LIGHT_OFFSET = 4;

    /** Slate ramps for Filament's --gray-* (50 lightest .. 950 darkest). Light is a touch darker in the mid tones for AA text. */
    public const GRAY_DARK = [
        50 => '#eeeef5', 100 => '#dfe0ea', 200 => '#c9cbda', 300 => '#aeb1c2', 400 => '#9a9eb1',
        500 => '#8387a0', 600 => '#5d6174', 700 => '#3a3e4c', 800 => '#262932', 900 => '#181b21', 950 => '#101216',
    ];
    public const GRAY_LIGHT = [
        50 => '#f3f6fa', 100 => '#e6ebf2', 200 => '#d3dae5', 300 => '#b6bfce', 400 => '#8b93a7',
        500 => '#5f677c', 600 => '#4a5266', 700 => '#343c4f', 800 => '#232938', 900 => '#181d29', 950 => '#101216',
    ];

    /**
     * Background tints (Settings tint). Each swaps blob 1-3 (blob 4 stays); the accent never changes. null blob = keep.
     * Values from the design system (data-tint ember|forest|dusk).
     */
    public const TINTS = [
        'none' => ['label' => 'None', 'dark' => null, 'light' => null],
        'ember' => ['label' => 'Ember',
            'dark' => ['rgba(255,170,80,.36)', 'rgba(214,72,96,.38)', 'rgba(171,130,112,.40)'],
            'light' => ['rgba(255,180,100,.50)', 'rgba(240,120,130,.36)', 'rgba(200,165,140,.42)']],
        'forest' => ['label' => 'Forest',
            'dark' => ['rgba(80,220,170,.34)', 'rgba(30,130,120,.44)', 'rgba(120,160,140,.40)'],
            'light' => ['rgba(90,215,170,.48)', 'rgba(90,190,170,.36)', 'rgba(150,185,165,.42)']],
        'dusk' => ['label' => 'Dusk',
            'dark' => ['rgba(140,150,255,.38)', 'rgba(190,80,170,.34)', 'rgba(112,120,171,.42)'],
            'light' => ['rgba(150,160,255,.46)', 'rgba(220,140,210,.34)', 'rgba(150,155,200,.42)']],
    ];

    /** Theme-independent contrast anchors used for derived custom accents. */
    public const BG_DARK = '#101216';
    public const BG_LIGHT = '#e6ebf2';
    public const ON_DARK_TEXT = '#0b1220';
}
