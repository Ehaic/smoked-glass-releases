<?php

declare(strict_types=1);

// Defaults mirror Ehaic\SmokedGlass\Support\Settings::DEFAULTS. Saved through Admin > Plugins > Smoked Glass > Settings
// (written to the panel .env); values are sanitised again before they reach any CSS.
return [
    'accent' => env('SMOKED_GLASS_ACCENT', 'sky'),
    'accent_custom' => env('SMOKED_GLASS_ACCENT_CUSTOM', '#56c2ff'),
    'tint' => env('SMOKED_GLASS_TINT', 'none'),
    'blur' => env('SMOKED_GLASS_BLUR', 28),
    'opacity' => env('SMOKED_GLASS_OPACITY', 0.38),
    'blobs' => env('SMOKED_GLASS_BLOBS', true),
    'grain' => env('SMOKED_GLASS_GRAIN', true),
    'animate' => env('SMOKED_GLASS_ANIMATE', true),
];
