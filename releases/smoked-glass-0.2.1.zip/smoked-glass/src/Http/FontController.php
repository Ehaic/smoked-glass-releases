<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Http;

use Ehaic\SmokedGlass\Support\Tokens;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

/**
 * Serves the two self-hosted Geist fonts. Pelican rc.2 does not publish plugin assets to /public, so the plugin
 * registers a tiny public panel route (whitelist of two file names, long immutable cache; the URL carries ?v=<version>).
 */
final class FontController
{
    public function __invoke(string $file): BinaryFileResponse
    {
        abort_unless(in_array($file, Tokens::FONTS, true), 404);
        $path = dirname(__DIR__, 2) . '/resources/fonts/' . $file;
        abort_unless(is_file($path), 404);

        return response()->file($path, [
            'Content-Type' => 'font/woff2',
            'Cache-Control' => 'public, max-age=31536000, immutable',
            'Access-Control-Allow-Origin' => '*',
        ]);
    }
}
