<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Support;

/**
 * Small colour helpers (no framework dependency). All inputs are validated #rrggbb strings.
 */
final class Color
{
    /** Normalise #rgb / #rrggbb (case-insensitive) to lowercase #rrggbb, or null when it is not a hex colour. */
    public static function normalizeHex(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $v = trim($value);
        if (preg_match('/^#([0-9a-fA-F]{6})$/D', $v, $m) === 1) {
            return '#' . strtolower($m[1]);
        }
        if (preg_match('/^#([0-9a-fA-F])([0-9a-fA-F])([0-9a-fA-F])$/D', $v, $m) === 1) {
            return strtolower('#' . $m[1] . $m[1] . $m[2] . $m[2] . $m[3] . $m[3]);
        }

        return null;
    }

    /** @return array{0:int,1:int,2:int} */
    public static function rgb(string $hex): array
    {
        $hex = self::normalizeHex($hex) ?? '#000000';

        return [hexdec(substr($hex, 1, 2)), hexdec(substr($hex, 3, 2)), hexdec(substr($hex, 5, 2))];
    }

    public static function rgbString(string $hex): string
    {
        return implode(',', self::rgb($hex));
    }

    /** "r,g,b" + alpha string -> rgba(r,g,b,alpha) (both already validated by the callers). */
    public static function rgbaFromRgb(string $rgb, string $alpha): string
    {
        return 'rgba(' . $rgb . ',' . $alpha . ')';
    }

    public static function fromRgb(int $r, int $g, int $b): string
    {
        return sprintf('#%02x%02x%02x', max(0, min(255, $r)), max(0, min(255, $g)), max(0, min(255, $b)));
    }

    /** Mix $hex with $other; $amount (0..1) is the share of $other. */
    public static function mix(string $hex, string $other, float $amount): string
    {
        $a = self::rgb($hex);
        $b = self::rgb($other);
        $amount = max(0.0, min(1.0, $amount));

        return self::fromRgb(
            (int) round($a[0] + ($b[0] - $a[0]) * $amount),
            (int) round($a[1] + ($b[1] - $a[1]) * $amount),
            (int) round($a[2] + ($b[2] - $a[2]) * $amount),
        );
    }

    public static function luminance(string $hex): float
    {
        $lin = static function (int $c): float {
            $c /= 255;

            return $c <= 0.03928 ? $c / 12.92 : (($c + 0.055) / 1.055) ** 2.4;
        };
        [$r, $g, $b] = self::rgb($hex);

        return 0.2126 * $lin($r) + 0.7152 * $lin($g) + 0.0722 * $lin($b);
    }

    /** WCAG contrast ratio, 1..21. */
    public static function contrast(string $a, string $b): float
    {
        $la = self::luminance($a);
        $lb = self::luminance($b);
        [$hi, $lo] = $la >= $lb ? [$la, $lb] : [$lb, $la];

        return ($hi + 0.05) / ($lo + 0.05);
    }

    /** Lighten $hex towards white until it reaches $ratio contrast against $background (max 20 steps). */
    public static function ensureContrast(string $hex, string $background, float $ratio = 4.5): string
    {
        for ($i = 0; $i < 20 && self::contrast($hex, $background) < $ratio; $i++) {
            $hex = self::mix($hex, '#ffffff', 0.08);
        }

        return $hex;
    }

    /** Darken $hex towards black until it reaches $ratio contrast against $background (max 30 steps). */
    public static function darkenForContrast(string $hex, string $background, float $ratio = 5.0): string
    {
        for ($i = 0; $i < 30 && self::contrast($hex, $background) < $ratio; $i++) {
            $hex = self::mix($hex, '#000000', 0.06);
        }

        return $hex;
    }

    /** Text colour (dark slate or white) that reads best on the given background. */
    public static function onColor(string $background): string
    {
        return self::contrast($background, '#0b1220') >= self::contrast($background, '#ffffff') ? '#0b1220' : '#ffffff';
    }
}
