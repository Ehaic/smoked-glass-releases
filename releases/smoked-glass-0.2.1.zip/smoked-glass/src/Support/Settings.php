<?php

declare(strict_types=1);

namespace Ehaic\SmokedGlass\Support;

/**
 * Smoked Glass settings: defaults, accent presets, tints, sanitising (lenient, for rendering) and validation (strict, for saving).
 * Everything that ends up inside the injected <style> block goes through here, so only whitelisted values,
 * normalised hex colours and clamped numbers can ever reach the CSS.
 */
final class Settings
{
    /** v4 defaults: Smoked Clear (dark) glass .38 / 28px; Frost (light) is derived (+0.17 / +4px, see Tokens). */
    public const DEFAULTS = [
        'accent' => 'sky',
        'accent_custom' => '#56c2ff',
        'tint' => 'none',
        'blur' => 28,
        'opacity' => 0.38,
        'blobs' => true,
        'grain' => true,
        'animate' => true,
    ];

    public const BLUR_RANGE = [0, 60];
    public const OPACITY_RANGE = [0.20, 0.95];

    /**
     * Accent presets. accent = dark-theme accent (text, outline, focus), light = headings/links on dark glass,
     * b1/b2 = primary button gradient (b2 is also the glow/stripe colour in the light theme), ink = accent as text in the
     * light theme (AA on Frost). Sky is the design-system default.
     */
    public const PRESETS = [
        'sky' => ['label' => 'Sky', 'accent' => '#56c2ff', 'light' => '#a6e0ff', 'b1' => '#7fd2ff', 'b2' => '#2aa6f0', 'ink' => '#0369a1'],
        'azure' => ['label' => 'Azure', 'accent' => '#4d9bff', 'light' => '#a9ccff', 'b1' => '#7db6ff', 'b2' => '#2a74e8', 'ink' => '#215ab5'],
        'cobalt' => ['label' => 'Cobalt', 'accent' => '#7d98ff', 'light' => '#c0ccff', 'b1' => '#93a9ff', 'b2' => '#3a5be0', 'ink' => '#3756d3'],
        'steel' => ['label' => 'Steel', 'accent' => '#8fa8c4', 'light' => '#cdd9e6', 'b1' => '#aebfd3', 'b2' => '#6b88a8', 'ink' => '#4f647c'],
        'ice' => ['label' => 'Ice', 'accent' => '#b8e6ff', 'light' => '#e2f5ff', 'b1' => '#d3f0ff', 'b2' => '#8cc9ee', 'ink' => '#476678'],
    ];

    /** @return list<string> */
    public static function tintKeys(): array
    {
        return array_keys(Tokens::TINTS);
    }

    /**
     * Lenient: take anything (config values, stale env), return a complete, safe settings array. Invalid fields fall back
     * to their default individually, numbers are clamped.
     *
     * @param  array<string, mixed>  $in
     * @return array{accent:string,accent_custom:string,tint:string,blur:int,opacity:float,blobs:bool,grain:bool,animate:bool}
     */
    public static function sanitize(array $in): array
    {
        $d = self::DEFAULTS;
        $accent = $in['accent'] ?? $d['accent'];
        $accent = is_string($accent) && (isset(self::PRESETS[$accent]) || $accent === 'custom') ? $accent : $d['accent'];
        $tint = $in['tint'] ?? $d['tint'];
        $tint = is_string($tint) && isset(Tokens::TINTS[$tint]) ? $tint : $d['tint'];

        return [
            'accent' => $accent,
            'accent_custom' => Color::normalizeHex($in['accent_custom'] ?? null) ?? $d['accent_custom'],
            'tint' => $tint,
            'blur' => (int) self::clamp($in['blur'] ?? null, self::BLUR_RANGE, (float) $d['blur']),
            'opacity' => round(self::clamp($in['opacity'] ?? null, self::OPACITY_RANGE, (float) $d['opacity']), 2),
            'blobs' => self::bool($in['blobs'] ?? null, $d['blobs']),
            'grain' => self::bool($in['grain'] ?? null, $d['grain']),
            'animate' => self::bool($in['animate'] ?? null, $d['animate']),
        ];
    }

    /**
     * Strict: used when saving. Returns [clean settings, errors by field]. Errors mean "do not save".
     *
     * @param  array<string, mixed>  $in
     * @return array{0:array<string,mixed>,1:array<string,string>}
     */
    public static function validate(array $in): array
    {
        $errors = [];
        $accent = $in['accent'] ?? null;
        if (!is_string($accent) || !(isset(self::PRESETS[$accent]) || $accent === 'custom')) {
            $errors['accent'] = 'Choose one of the accent presets or custom.';
        }
        $custom = $in['accent_custom'] ?? null;
        if (($accent === 'custom' || ($custom !== null && $custom !== '')) && Color::normalizeHex($custom) === null) {
            $errors['accent_custom'] = 'Enter a hex colour such as #56c2ff.';
        }
        $tint = $in['tint'] ?? null;
        if (!is_string($tint) || !isset(Tokens::TINTS[$tint])) {
            $errors['tint'] = 'Choose None, Ember, Forest or Dusk.';
        }
        foreach (['blur' => self::BLUR_RANGE, 'opacity' => self::OPACITY_RANGE] as $key => [$min, $max]) {
            $v = $in[$key] ?? null;
            if (!is_int($v) && !is_float($v) && !(is_string($v) && is_numeric($v))) {
                $errors[$key] = 'Enter a number.';
            } elseif ((float) $v < $min || (float) $v > $max) {
                $errors[$key] = "Must be between {$min} and {$max}.";
            }
        }
        foreach (['blobs', 'grain', 'animate'] as $key) {
            if (!array_key_exists($key, $in) || !(is_bool($in[$key]) || in_array($in[$key], [0, 1, '0', '1', 'true', 'false'], true))) {
                $errors[$key] = 'Must be on or off.';
            }
        }

        return [self::sanitize($in), $errors];
    }

    /** @param array{0:int|float,1:int|float} $range */
    private static function clamp(mixed $v, array $range, float $default): float
    {
        if (!is_int($v) && !is_float($v) && !(is_string($v) && is_numeric($v))) {
            return $default;
        }
        $f = (float) $v;
        if (!is_finite($f)) {
            return $default;
        }

        return max((float) $range[0], min((float) $range[1], $f));
    }

    private static function bool(mixed $v, bool $default): bool
    {
        if (is_bool($v)) {
            return $v;
        }
        if (in_array($v, [1, '1', 'true', 'on', 'yes'], true)) {
            return true;
        }
        if (in_array($v, [0, '0', 'false', 'off', 'no'], true)) {
            return false;
        }

        return $default;
    }

    /**
     * Resolved accent colours for a settings array. Custom accents get a derived light tone, button gradient and
     * light-theme ink; the dark accent is lightened until it reaches WCAG AA (4.5:1) on the dark base and the ink is
     * darkened until it reaches 5:1 on the Frost base.
     *
     * @param  array<string, mixed>  $s  sanitised settings
     * @return array{accent:string,light:string,b1:string,b2:string,ink:string,on:string}
     */
    public static function accentColors(array $s): array
    {
        if (($s['accent'] ?? 'sky') !== 'custom' && isset(self::PRESETS[$s['accent'] ?? 'sky'])) {
            $p = self::PRESETS[$s['accent']];
            $accent = $p['accent'];
            $light = $p['light'];
            $b1 = $p['b1'];
            $b2 = $p['b2'];
            $ink = $p['ink'];
        } else {
            $base = Color::normalizeHex($s['accent_custom'] ?? null) ?? self::PRESETS['sky']['accent'];
            $accent = Color::ensureContrast($base, Tokens::BG_DARK, 4.5);
            $light = Color::ensureContrast(Color::mix($accent, '#ffffff', 0.45), Tokens::BG_DARK, 7.0);
            $b1 = Color::mix($base, '#ffffff', 0.25);
            $b2 = Color::mix($base, '#000000', 0.18);
            $ink = Color::darkenForContrast($b2, Tokens::BG_LIGHT, 5.0);
        }
        $dark = Tokens::ON_DARK_TEXT;

        return [
            'accent' => $accent, 'light' => $light, 'b1' => $b1, 'b2' => $b2, 'ink' => $ink,
            'on' => Color::contrast($b2, $dark) >= 4.5 && Color::contrast($b1, $dark) >= 4.5 ? $dark : '#ffffff',
        ];
    }
}
